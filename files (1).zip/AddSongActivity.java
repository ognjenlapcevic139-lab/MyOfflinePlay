package com.example.demospotifyclone;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;

public class AddSongActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Theme_DemoSpotifyClone_Dark);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_song);

        EditText etTitle = findViewById(R.id.etTitle);
        EditText etDesc = findViewById(R.id.etDescription);
        EditText etYoutube = findViewById(R.id.etYoutubeUrl);
        Button btnSave = findViewById(R.id.btnSaveSong);

        btnSave.setOnClickListener(v -> {
            // TODO: validacija i upis pesme u SharedPreferences
            finish();
        });
    }
}