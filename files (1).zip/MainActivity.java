package com.example.demospotifyclone;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

// Glavni ekran: lista pesama
public class MainActivity extends AppCompatActivity {
    private ArrayList<Song> songs = new ArrayList<>();
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Theme_DemoSpotifyClone_Dark); // Dark tema!
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listViewSongs);
        loadSongs();

        ArrayAdapter<Song> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, songs);
        listView.setAdapter(adapter);

        // Otvaranje playera na klik
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Song s = songs.get(position);
            Intent intent = new Intent(this, AudioPlayerActivity.class);
            intent.putExtra("SONG_PATH", s.localPath);
            startActivity(intent);
        });

        findViewById(R.id.btnAddSong).setOnClickListener(v -> {
            startActivity(new Intent(this, AddSongActivity.class));
        });
    }

    private void loadSongs() {
        // TODO: učitaj listu pesama iz SharedPreferences
        // Demo: dodavanje jedne simulirane pesme
        songs.clear();
        songs.add(new Song("Demo pesma", "Opis demo pesme", "https://youtu.be/test", getFilesDir() + "/demo.mp3"));
    }
}