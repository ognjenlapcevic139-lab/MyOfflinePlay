// Model za pesmu
public class Song {
    public String title;
    public String description;
    public String youtubeUrl;
    public String localPath; // za offline
    public Song(String title, String description, String youtubeUrl, String localPath) {
        this.title = title;
        this.description = description;
        this.youtubeUrl = youtubeUrl;
        this.localPath = localPath;
    }
}