# MyOfflinePlay - Android Playlista App (Java, Dark Mode)

Ovo je demo Android aplikacija napravljena u Java jeziku, sa modernim Dark dizajnom za **objavljivanje** i **slušanje pesama offline**.

## Funkcije
- Dodavanje pesme sa YouTube linkom, nazivom i opisom
- Lista svih pesama (feed katalog)
- Offline puštanje pesama (demo koristi sample fajl: demo.mp3)
- Dark mode – prilagođeno za noćni rad

## Kako koristiti?
1. Kloniraj repozitorijum i otvori u Android Studio
2. Ubaci `demo.mp3` u `app/src/main/assets/` folder
3. Pokreni aplikaciju na emulatoru ili telefonu
4. Dodaj pesmu, popuni polja i uživaj u offline slušanju!

## Složeni unapred
- Nema ručne konfiguracije: sve radi automatski!
- Kôd je spreman za dalje unapređenje (pravi audio download, user login, komentari…)

## Autorska napomena
Svi deljeni, modifikovani i korišćeni kodovi zasnovani su na edukativnim i demo primerima bez garancije za produkcijsko izdanje.

---

**Ovaj projekat je open-source za deljenje sa drugima!**