package com.example.myofflineplay;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

public class AddSongActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.DarkTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_song);

        EditText etTitle = findViewById(R.id.etTitle);
        EditText etDesc = findViewById(R.id.etDescription);
        EditText etYoutube = findViewById(R.id.etYoutubeUrl);
        findViewById(R.id.btnSaveSong).setOnClickListener(v -> {
            String title = etTitle.getText().toString();
            String desc = etDesc.getText().toString();
            String ytUrl = etYoutube.getText().toString();

            if (title.isEmpty() || desc.isEmpty() || ytUrl.isEmpty()) {
                Toast.makeText(this, "Popunite sva polja!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Simuliraj preuzimanje: kopiraj demo.mp3 iz assets!
            String fileName = title.replaceAll("\\s+", "_") + ".mp3";
            String outputPath = getFilesDir() + "/" + fileName;
            try {
                File outFile = new File(outputPath);
                if (!outFile.exists()) {
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        byte[] buffer = getAssets().open("demo.mp3").readAllBytes();
                        fos.write(buffer);
                    }
                }
            } catch(Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Greška pri preuzimanju!", Toast.LENGTH_SHORT).show();
                return;
            }

            Song song = new Song(title, desc, ytUrl, outputPath);

            SharedPreferences prefs = getSharedPreferences("songs_db", MODE_PRIVATE);
            String json = prefs.getString("songs_list", "[]");
            ArrayList<Song> list = new Gson().fromJson(json, new TypeToken<ArrayList<Song>>(){}.getType());
            list.add(song);
            prefs.edit().putString("songs_list", new Gson().toJson(list)).apply();

            Toast.makeText(this, "Pesma sačuvana!", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}