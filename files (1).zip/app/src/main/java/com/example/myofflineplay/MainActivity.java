package com.example.myofflineplay;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Song> songs = new ArrayList<>();
    private ListView listView;
    private ArrayAdapter<Song> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.DarkTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listViewSongs);

        loadSongs();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, songs);
        listView.setAdapter(adapter);

        // Play offline
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Song s = songs.get(position);
            Intent intent = new Intent(this, AudioPlayerActivity.class);
            intent.putExtra("SONG_PATH", s.localPath);
            startActivity(intent);
        });

        findViewById(R.id.btnAddSong).setOnClickListener(v -> {
            Intent intent = new Intent(this, AddSongActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadSongs();
        adapter.notifyDataSetChanged();
    }

    private void loadSongs() {
        SharedPreferences prefs = getSharedPreferences("songs_db", MODE_PRIVATE);
        String json = prefs.getString("songs_list", "[]");
        songs.clear();
        songs.addAll(new Gson().fromJson(json, new TypeToken<ArrayList<Song>>(){}.getType()));
    }
}