package com.example.myofflineplay;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.Toast;

public class AudioPlayerActivity extends Activity {
    private MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.DarkTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_player);

        String songPath = getIntent().getStringExtra("SONG_PATH");
        mp = new MediaPlayer();
        try {
            mp.setDataSource(songPath);
            mp.prepare();
            mp.start();
            Toast.makeText(this, "Reprodukcija pesme...", Toast.LENGTH_SHORT).show();
        } catch(Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Ne može da pusti pesmu.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mp != null) {
            mp.release();
        }
    }
}