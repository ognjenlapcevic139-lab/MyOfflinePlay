package com.example.demospotifyclone;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;

public class AudioPlayerActivity extends Activity {
    private MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Theme_DemoSpotifyClone_Dark);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_player);

        String songPath = getIntent().getStringExtra("SONG_PATH");
        mp = new MediaPlayer();
        try {
            mp.setDataSource(songPath);
            mp.prepare();
            mp.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mp != null) {
            mp.stop();
            mp.release();
        }
    }
}